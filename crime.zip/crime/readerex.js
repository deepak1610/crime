var fs=require('fs');
var lineReader = require('readline').createInterface({
 input: fs.createReadStream('ex.csv')
});

var des,typ,yr;
//var a,b;
var data;
var count=0;
function yeardata(yr,under500,above500)
{
 this.yr=yr;
 this.under500=under500;
 this.above500=above500;
}
var years=[];
var yearspdata=[];


lineReader.on('line', function (line)
{
count=count+1;
 if(count==1)
 {
   //console.log();
    var h=line.split(",");
    //console.log(h);
for(var i=0;i<h.length;i++)
 {
   if(h[i]=="Description")
   {
     des=i;


   }
   if(h[i]=="Primary Type")
   {
     typ=i;
   }
   if(h[i]=="Year")
   {
     yr=i;
   }

}
}
 else if(count>=2)
 {
    data=line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
var year=(data[yr]);
var index=years.indexOf(year);
if(index<0)
{
 years.push(year);
 var yrdata=new yeardata(year,0,0);
 if(data[des]=='$500 AND UNDER')
 {
   yrdata.under500=yrdata.under500+1;
 }
 else if(data[des]=='$500 AND UNDER')
 {
   yrdata.above500=  yrdata.above500+1;
 }
 yearspdata.push(yrdata);

}
else
{
var yrdata=yearspdata[index];
if(data[des]=='$500 AND UNDER')
{
 yrdata.under500=yrdata.under500+1;
}
else if(data[des]=='OVER $500')
{
 yrdata.above500=  yrdata.above500+1;
}
yearspdata[index]=yrdata;

}


 }
//  console.log(yearspdata);
});
lineReader.on('close', function() {

  yearspdata.sort(function(a,b){
    return parseInt(a.yr)-parseInt(b.yr);
  });

 console.log(yearspdata);


   var file=JSON.stringify(yearspdata);
   fs.writeFile("part_1_json.json",file,"utf8",function(error){
     if(error)
     throw error;
     });

});
